package com.hotel.Hotel_Reservations;

import com.hotel.model.*;
import com.hotel.service.*;

import java.util.List;
import java.util.Scanner;

public class HotelReservationSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Service objects
        HotelService hotelService = new HotelService();
        RoomService roomService = new RoomService();
        GuestService guestService = new GuestService();
        BookingService bookingService = new BookingService();
        PaymentService paymentService = new PaymentService();

        while (true) {
            System.out.println("\n===== Hotel Reservation System =====");
            System.out.println("1. Add Hotel");
            System.out.println("2. View All Hotels");
            System.out.println("3. Add Room");
            System.out.println("4. View All Rooms");
            System.out.println("5. Add Guest");
            System.out.println("6. View All Guests");
            System.out.println("7. Make a Booking");
            System.out.println("8. View All Bookings");
            System.out.println("9. Make a Payment");
            System.out.println("10. View All Payments");
            System.out.println("11. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter hotel name: ");
                    String hotelName = scanner.nextLine();
                    System.out.print("Enter hotel location: ");
                    String location = scanner.nextLine();
                    hotelService.addHotel(new Hotel(hotelName, location));
                    System.out.println("Hotel added successfully!");
                    break;

                case 2:
                    List<Hotel> hotels = hotelService.getAllHotels();
                    if (hotels.isEmpty()) {
                        System.out.println("No hotels found.");
                    } else {
                        for (Hotel h : hotels) {
                            System.out.println(h);
                        }
                    }
                    break;

                case 3:
                    System.out.print("Enter room type (Single/Double): ");
                    String type = scanner.nextLine();
                    System.out.print("Enter room price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter hotel ID: ");
                    int hotelId = scanner.nextInt();

                    if (hotelService.getHotelById(hotelId) == null) {
                        System.out.println("Error: Hotel ID not found!");
                    } else {
                        roomService.addRoom(new Room(type, price, hotelId));
                        System.out.println("Room added successfully!");
                    }
                    break;

                case 4:
                    List<Room> rooms = roomService.getAllRooms();
                    if (rooms.isEmpty()) {
                        System.out.println("No rooms available.");
                    } else {
                        for (Room r : rooms) {
                            System.out.println(r);
                        }
                    }
                    break;

                case 5:
                    System.out.print("Enter guest name: ");
                    String guestName = scanner.nextLine();
                    System.out.print("Enter guest email: ");
                    String guestEmail = scanner.nextLine();
                    guestService.addGuest(new Guest(guestName, guestEmail));
                    System.out.println("Guest added successfully!");
                    break;

                case 6:
                    List<Guest> guests = guestService.getAllGuests();
                    if (guests.isEmpty()) {
                        System.out.println("No guests found.");
                    } else {
                        for (Guest g : guests) {
                            System.out.println(g);
                        }
                    }
                    break;

                case 7:
                    System.out.print("Enter guest ID: ");
                    int guestId = scanner.nextInt();
                    System.out.print("Enter room ID: ");
                    int roomId = scanner.nextInt();

                    // Validate Guest and Room IDs
                    Guest guest = guestService.getGuestById(guestId);
                    Room room = roomService.getRoomById(roomId);

                    if (guest == null) {
                        System.out.println("Error: Guest ID not found!");
                    } else if (room == null) {
                        System.out.println("Error: Room ID not found!");
                    } else {
                        Booking booking = new Booking(guestId, roomId);
                        bookingService.addBooking(booking);
                        System.out.println("Booking successful! Booking ID: " + booking.getId());
                    }
                    break;


                case 8:
                    List<Booking> bookings = bookingService.getAllBookings();
                    if (bookings.isEmpty()) {
                        System.out.println("No bookings found.");
                    } else {
                        for (Booking b : bookings) {
                            System.out.println(b);
                        }
                    }
                    break;

                case 9:
                    System.out.print("Enter booking ID: ");
                    int bookingId = scanner.nextInt();
                    System.out.print("Enter payment amount: ");
                    double amount = scanner.nextDouble();

                    // Validate if Booking exists
                    Booking booking = bookingService.getBookingById(bookingId);
                    
                    if (booking == null) {
                        System.out.println("Error: Booking ID not found!");
                    } else {
                        Payment payment = new Payment(bookingId, amount);
                        paymentService.addPayment(payment);
                        System.out.println("Payment successful! Payment ID: " + payment.getId());
                    }
                    break;


                case 10:
                    List<Payment> payments = paymentService.getAllPayments();
                    if (payments.isEmpty()) {
                        System.out.println("No payments found.");
                    } else {
                        for (Payment p : payments) {
                            System.out.println(p);
                        }
                    }
                    break;

                case 11:
                    System.out.println("Exiting system...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
