package com.hotel.model;


public class Payment {
    private int id;
    private int bookingId;
    private double amount;

    // Constructor
    public Payment(int bookingId, double amount) {
        this.bookingId = bookingId;
        this.amount = amount;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getBookingId() { return bookingId; }
    public void setBookingId(int bookingId) { this.bookingId = bookingId; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    @Override
    public String toString() {
        return "Payment ID: " + id + ", Booking ID: " + bookingId + ", Amount: " + amount;
    }
}
