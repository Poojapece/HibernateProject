package com.hotel.model;

import javax.persistence.*;

@Entity
@Table(name = "rooms")
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    private int roomNumber;
    private double price;
    
    @ManyToOne
    @JoinColumn(name = "hotel_id", nullable = false)
    private Hotel hotel; 

    // Constructors
    public Room() {}

    public Room(int type, double price, Hotel hotelId) {
        this.roomNumber = type;
        this.price = price;
        this.hotel = hotelId;
    }

    public Room(String type, double price2, int hotelId) {
		// TODO Auto-generated constructor stub
	}

	// Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getRoomNumber() { return roomNumber; }
    public void setRoomNumber(int roomNumber) { this.roomNumber = roomNumber; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public Hotel getHotel() { return hotel; }
    public void setHotel(Hotel hotel) { this.hotel = hotel; }

    @Override
    public String toString() {
        return "Room{id=" + id + ", roomNumber=" + roomNumber + ", price=" + price + "}";
    }
}

