package com.hotel.model;


public class Booking {
    private int id;
    private int guestId;
    private int roomId;

    // Constructor
    public Booking(int guestId, int roomId) {
        this.guestId = guestId;
        this.roomId = roomId;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getGuestId() { return guestId; }
    public void setGuestId(int guestId) { this.guestId = guestId; }

    public int getRoomId() { return roomId; }
    public void setRoomId(int roomId) { this.roomId = roomId; }

    @Override
    public String toString() {
        return "Booking ID: " + id + ", Guest ID: " + guestId + ", Room ID: " + roomId;
    }
}
