package com.hotel.service;

import com.hotel.model.Payment;
import com.hotel.repository.PaymentRepository;

import java.util.List;

public class PaymentService {
    private PaymentRepository paymentRepository = new PaymentRepository();

    public void addPayment(Payment payment) {
        paymentRepository.addPayment(payment);
    }

    public List<Payment> getAllPayments() {
        return paymentRepository.getAllPayments();
    }

    public Payment getPaymentById(int id) {
        return paymentRepository.getPaymentById(id);
    }
}
