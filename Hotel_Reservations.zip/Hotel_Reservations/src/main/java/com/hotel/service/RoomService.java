package com.hotel.service;


import com.hotel.model.Room;
import com.hotel.repository.RoomRepository;

import java.util.List;

public class RoomService {
    private RoomRepository roomRepository = new RoomRepository();

    public void addRoom(Room room) {
        roomRepository.saveRoom(room);
        System.out.println("Room added successfully!");
    }

    public List<Room> getAllRooms() {
        return roomRepository.getAllRooms();
    }

    public Room getRoomById(int id) {
        return roomRepository.getRoomById(id);
    }

    public void deleteRoom(int id) {
        roomRepository.deleteRoom(id);
        System.out.println("Room deleted successfully!");
    }
}


