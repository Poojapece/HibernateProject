package com.hotel.service;


import com.hotel.model.Guest;
import com.hotel.repository.GuestRepository;

import java.util.List;

public class GuestService {
    private GuestRepository guestRepository = new GuestRepository();

    public void addGuest(Guest guest) {
        guestRepository.saveGuest(guest);
        System.out.println("Guest added successfully!");
    }

    public List<Guest> getAllGuests() {
        return guestRepository.getAllGuests();
    }

    public Guest getGuestById(int id) {
        return guestRepository.getGuestById(id);
    }

    public void deleteGuest(int id) {
        guestRepository.deleteGuest(id);
        System.out.println("Guest deleted successfully!");
    }
}


