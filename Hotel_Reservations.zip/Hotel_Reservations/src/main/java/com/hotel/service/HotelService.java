package com.hotel.service;

import com.hotel.model.Hotel;
import com.hotel.repository.HotelRepository;

import java.util.List;

public class HotelService {
    private HotelRepository hotelRepository = new HotelRepository();

    public void addHotel(Hotel hotel) {
        hotelRepository.saveHotel(hotel);
        System.out.println("Hotel added successfully!");
    }

    public List<Hotel> getAllHotels() {
        return hotelRepository.getAllHotels();
    }

    public Hotel getHotelById(int id) {
        return hotelRepository.getHotelById(id);
    }

    public void deleteHotel(int id) {
        hotelRepository.deleteHotel(id);
        System.out.println("Hotel deleted successfully!");
    }
}


