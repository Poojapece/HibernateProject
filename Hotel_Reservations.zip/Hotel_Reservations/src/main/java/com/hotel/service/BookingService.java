package com.hotel.service;

import com.hotel.model.Booking;
import com.hotel.repository.BookingRepository;

import java.util.List;

public class BookingService {
    private BookingRepository bookingRepository = new BookingRepository();

    public void addBooking(Booking booking) {
        bookingRepository.addBooking(booking);
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.getAllBookings();
    }

    public Booking getBookingById(int id) {
        return bookingRepository.getBookingById(id);
    }
}
