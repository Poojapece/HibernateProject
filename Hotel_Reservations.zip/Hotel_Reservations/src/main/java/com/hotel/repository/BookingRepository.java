package com.hotel.repository;

import com.hotel.model.Booking;
import java.util.ArrayList;
import java.util.List;

public class BookingRepository {
    private List<Booking> bookings = new ArrayList<>();
    private int bookingCounter = 1;

    public void addBooking(Booking booking) {
        booking.setId(bookingCounter++);
        bookings.add(booking);
    }

    public List<Booking> getAllBookings() {
        return bookings;
    }

    public Booking getBookingById(int id) {
        for (Booking b : bookings) {
            if (b.getId() == id) {
                return b;
            }
        }
        return null;
    }
}
