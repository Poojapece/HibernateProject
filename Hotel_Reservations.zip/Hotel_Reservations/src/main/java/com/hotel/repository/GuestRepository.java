package com.hotel.repository;

import com.hotel.model.Guest;
import com.hotel.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class GuestRepository {

    // Save a new guest
    public void saveGuest(Guest guest) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(guest);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    // Get all guests
    public List<Guest> getAllGuests() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Guest", Guest.class).list();
        }
    }

    // Get guest by ID
    public Guest getGuestById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Guest.class, id);
        }
    }

    // Delete guest by ID
    public void deleteGuest(int id) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Guest guest = session.get(Guest.class, id);
            if (guest != null) {
                session.delete(guest);
                transaction.commit();
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }
}

