package com.hotel.repository;

import com.hotel.model.Payment;
import java.util.ArrayList;
import java.util.List;

public class PaymentRepository {
    private List<Payment> payments = new ArrayList<>();
    private int paymentCounter = 1;

    public void addPayment(Payment payment) {
        payment.setId(paymentCounter++);
        payments.add(payment);
    }

    public List<Payment> getAllPayments() {
        return payments;
    }

    public Payment getPaymentById(int id) {
        for (Payment p : payments) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }
}
